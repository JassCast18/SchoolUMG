﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoDatos.Models
{
    public class AlumnoAsignatura
    {
        public string NombreAlumno { get; set; }
        public string NombreAsignatura { get; set; }
    }
}
